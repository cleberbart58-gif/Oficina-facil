# Oficina Fácil

Aplicativo mobile para gestão de oficinas e mecânicos.

## Identificação
- Nome: Oficina Fácil
- App ID: br.com.oficinafacil.app
- Versão inicial: 1.0.0
- Plataforma Android: Capacitor

## Observação
A versão atual contém a interface/demo fornecida e está preparada para ser empacotada como aplicativo Android. Recursos comerciais reais (login, banco de dados, sincronização entre usuários e assinaturas) precisam ser ligados a um backend e aos sistemas de cobrança antes do lançamento comercial.

## Android
1. `npm install`
2. `npx cap add android`
3. `npx cap sync android`
4. Abrir o projeto Android no Android Studio e gerar o AAB assinado.
